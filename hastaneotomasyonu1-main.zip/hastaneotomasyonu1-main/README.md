# hastaneotomasyonu1
visual programming windows form application c# /patient registration form

Beyza KAPLAN
Simge ÇİFTCİ
Muhammed Beraat KILDACI
Osman Can YILMAZ
